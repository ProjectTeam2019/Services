<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt  =  json_decode($data);
$shopping_list_ing = $dt->shopping_list_ing;
$user_id = $dt->user_id;
$recipe_id = $dt->recipe_id;
echo $query = "insert into shopping_list(shopping_list_ing,user_id,recipe_id) values('$shopping_list_ing','$user_id','$recipe_id')";
$cn->query($query);
echo "Successful";
?>
