<?php
    $con = new mysqli("localhost","root","","TasteBuds");
    $query = "select * from shopping_list"; //where shopping_list_id='$shopping_list_id'";
    $rows = $con->query($query);
    while ($row = $rows->fetch_assoc())
    {
        $pp[] = $row;
    }
    echo json_encode($pp);
?>



