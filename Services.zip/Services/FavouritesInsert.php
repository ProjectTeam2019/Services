<?php
$cn = new mysqli("localhost","root","","TasteBuds");
$data = file_get_contents('php://input');
$dt  =  json_decode($data);
$recipe_id = $dt->recipe_id;
$user_id = $dt->user_id;
echo $query = "insert into favourites(recipe_id,user_id) values('$recipe_id','$user_id')";
$cn->query($query);
echo "Successful";
?>
